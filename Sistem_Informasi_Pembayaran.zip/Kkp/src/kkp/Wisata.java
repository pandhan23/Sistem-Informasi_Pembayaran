/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package kkp;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
/**
 *
 * @author HP
 */
public class Wisata extends javax.swing.JFrame {
    
    public void kode_wisata_otomatis(){
      String kode="WS-000";
      int i=0;
    try{
        
        Connection kon=DriverManager.getConnection("jdbc:mysql://localhost:3306/pembayaran","root","");
        Statement stat = kon.createStatement();
        ResultSet rs = stat.executeQuery("select id_wisata from wisata");
        
        while(rs.next()){
            kode = rs.getString("id_wisata");
        }
        kode = kode.substring(4);
        i = Integer.parseInt(kode)+1;
        kode = "00"+i;
        kode = "WS-"+kode.substring(kode.length()-3);
        JIw.setText(kode);
       
    }catch(SQLException e){
        System.out.println(e.getMessage());
    }
        
    }
    
private Connection kon = new koneksi().connect();
private DefaultTableModel tabmode;
    /**
     * Creates new form Wisata
     */
    public Wisata() {
        initComponents();
        datatable();
        setLocationRelativeTo(null);
        customer();
        paket();
        aktif();
        kosong();
        kode_wisata_otomatis();
    }

    protected void datatable() {
        Object[] Baris ={"id_wisata","id_wisatawan","nama","kode_paket","nama_paket","tujuan","harga","hotel","tnggl"};
        tabmode = new DefaultTableModel(null, Baris);
        tabel2.setModel(tabmode);
        String sql =  "select * from wisata inner join wisatawan on wisata.id_wisatawan = wisatawan.id_wisatawan inner join paket on wisata.kode_paket = paket.kode_paket";
        try {
            java.sql.Statement stat = kon.createStatement();
            ResultSet hasil = stat.executeQuery(sql);
            while(hasil.next()){
                String a = hasil.getString("id_wisata");
                String b = hasil.getString("id_wisatawan");
                String c = hasil.getString("nama");
               String d = hasil.getString("kode_paket");
                  String e = hasil.getString("nama_paket");
                     String f = hasil.getString("tujuan");
                        String g = hasil.getString("harga");
                          String h = hasil.getString("hotel");
                String i = hasil.getString("tanggl");
              String[] data={a,b,c,d,e,f,g,h,i};
                tabmode.addRow(data);
            }
        } catch (Exception e){}
    }
    
    protected void cari(){
        java.util.Date utilStartDate = tgl_awal.getDate();
        java.sql.Date sqlStartDate = new java.sql.Date(utilStartDate.getTime());
        java.util.Date utilStartDate2 = tgl_akhir.getDate();
        java.sql.Date sqlStartDate2 = new java.sql.Date(utilStartDate2.getTime());
        tgl.setText(sqlStartDate.toString() +" s/d "+sqlStartDate2.toString());
        Object[] Baris ={"id_wisata","id_wisatawan","nama","kode_paket","nama_paket","tujuan","harga","hotel","tnggl"};
        tabmode = new DefaultTableModel(null, Baris);
        tabel2.setModel(tabmode);
        try {
        String sql =  "select * from wisata inner join wisatawan on wisata.id_wisatawan = wisatawan.id_wisatawan inner join paket on wisata.kode_paket = paket.kode_paket"
                + " WHERE tanggl BETWEEN '" + sqlStartDate.toString() + "' AND '" + sqlStartDate2.toString() + "'"
                + " ORDER BY tanggl ASC";
            PreparedStatement pst = kon.prepareStatement(sql);
            ResultSet hasil = pst.executeQuery(sql);
            while(hasil.next()){
            String a = hasil.getString("id_wisata");
                String b = hasil.getString("id_wisatawan");
                String c = hasil.getString("nama");
               String d = hasil.getString("kode_paket");
                  String e = hasil.getString("nama_paket");
                     String f = hasil.getString("tujuan");
                        String g = hasil.getString("harga");
                          String h = hasil.getString("hotel");
                String i = hasil.getString("tanggl");
              String[] data={a,b,c,d,e,f,g,h,i};
              tabmode.addRow(data);
            }
        } catch (Exception e){
        JOptionPane.showMessageDialog(null,e);}
    }
    
    private void customer(){
        try{
          String sql="select * from wisatawan";
          PreparedStatement pst = kon.prepareStatement(sql);
          ResultSet rs=pst.executeQuery(sql);          
          while(rs.next()){
          String name =rs.getString("id_wisatawan");
          Cs.addItem(name);
          }          
        }catch(Exception e){
        JOptionPane.showMessageDialog(null,e);
        }
    }
    
      private void customer2(){
        try{
          String sql="select * from wisatawan where id_wisatawan='"+Cs.getSelectedItem()+"';";
          PreparedStatement pst = kon.prepareStatement(sql);
          ResultSet rs=pst.executeQuery(sql); 
          while(rs.next()){   
          String name =rs.getString("nama");
          Jcs.setText(name);}
            }catch(Exception e){
        JOptionPane.showMessageDialog(null,e);
        }
    }
      
      private void paket(){
        try{
          String sql="select * from paket";
          PreparedStatement pst = kon.prepareStatement(sql);
          ResultSet rs=pst.executeQuery(sql);          
          while(rs.next()){
          String name =rs.getString("kode_paket");
          Dp.addItem(name);
          }          
        }catch(Exception e){
        JOptionPane.showMessageDialog(null,e);
        }
    }
    
      private void paket2(){
        try{
          String sql="select * from paket where kode_paket='"+Dp.getSelectedItem()+"';";
          PreparedStatement pst = kon.prepareStatement(sql);
          ResultSet rs=pst.executeQuery(sql); 
          while(rs.next()){   
          String name =rs.getString("nama_paket");
          tNm.setText(name);     
          }
            }catch(Exception e){
        JOptionPane.showMessageDialog(null,e);
        }
    }
      
          private void paket3(){
        try{
          String sql="select * from paket where kode_paket='"+Dp.getSelectedItem()+"';";
          PreparedStatement pst = kon.prepareStatement(sql);
          ResultSet rs=pst.executeQuery(sql); 
          while(rs.next()){   
          String name =rs.getString("tujuan");
          tJ.setText(name);     
          }
            }catch(Exception e){
        JOptionPane.showMessageDialog(null,e);
        }
    }
          
          private void paket4(){
        try{
          String sql="select * from paket where kode_paket='"+Dp.getSelectedItem()+"';";
          PreparedStatement pst = kon.prepareStatement(sql);
          ResultSet rs=pst.executeQuery(sql); 
          while(rs.next()){   
          String name =rs.getString("harga");
          tH.setText(name);     
          }
            }catch(Exception e){
        JOptionPane.showMessageDialog(null,e);
        }
    }
              
         private void paket5(){
        try{
          String sql="select * from paket where kode_paket='"+Dp.getSelectedItem()+"';";
          PreparedStatement pst = kon.prepareStatement(sql);
          ResultSet rs=pst.executeQuery(sql); 
          while(rs.next()){   
          String name =rs.getString("hotel");
          tHo.setText(name);     
          }
            }catch(Exception e){
        JOptionPane.showMessageDialog(null,e);
        }
    }
      
      public void aktif() {
    JIw.setEnabled(true);
    Jcs.setEnabled(true);
        tNm.setEnabled(true);
         tJ.setEnabled(true);
          tH.setEnabled(true);
           tHo.setEnabled(true);
  tanggal.setEnabled(true);
  
    
    }
public void kosong() {
       JIw.setText("");
       Jcs.setText("");
         tNm.setText("");
           tJ.setText("");
             tH.setText("");
               tHo.setText("");
       tanggal.setCalendar(null);
       
       
    }
      
    
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel2 = new javax.swing.JPanel();
        jLabel7 = new javax.swing.JLabel();
        jButton7 = new javax.swing.JButton();
        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        JIw = new javax.swing.JTextField();
        Cs = new javax.swing.JComboBox<>();
        Jcs = new javax.swing.JTextField();
        Dp = new javax.swing.JComboBox<>();
        tanggal = new com.toedter.calendar.JDateChooser();
        tgl_awal = new com.toedter.calendar.JDateChooser();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        tNm = new javax.swing.JTextField();
        jLabel10 = new javax.swing.JLabel();
        tJ = new javax.swing.JTextField();
        jLabel11 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        tgl_akhir = new com.toedter.calendar.JDateChooser();
        tH = new javax.swing.JTextField();
        tHo = new javax.swing.JTextField();
        cari = new javax.swing.JButton();
        tgl = new javax.swing.JLabel();
        jS = new javax.swing.JButton();
        BE = new javax.swing.JButton();
        Bhp = new javax.swing.JButton();
        clear = new javax.swing.JButton();
        jPanel3 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tabel2 = new javax.swing.JTable();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        jPanel2.setBackground(new java.awt.Color(51, 102, 255));

        jLabel7.setFont(new java.awt.Font("Comic Sans MS", 1, 28)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(51, 255, 0));
        jLabel7.setText("Destinasi Wisata");

        jButton7.setFont(new java.awt.Font("Comic Sans MS", 1, 14)); // NOI18N
        jButton7.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/Back.png"))); // NOI18N
        jButton7.setText("Back");
        jButton7.setMaximumSize(new java.awt.Dimension(105, 33));
        jButton7.setMinimumSize(new java.awt.Dimension(105, 33));
        jButton7.setPreferredSize(new java.awt.Dimension(105, 33));
        jButton7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton7ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel7)
                .addGap(411, 411, 411)
                .addComponent(jButton7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(21, 21, 21))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jButton7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel7))
                .addContainerGap())
        );

        jPanel1.setBackground(new java.awt.Color(51, 102, 255));
        jPanel1.setBorder(javax.swing.BorderFactory.createTitledBorder("Form Destinasi"));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel1.setText("Kode Wisata :");
        jPanel1.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(65, 51, -1, -1));

        jLabel2.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel2.setText("Kode Wisatawan :");
        jPanel1.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 90, -1, -1));

        jLabel3.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel3.setText("Nama :");
        jPanel1.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 130, -1, -1));

        jLabel4.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel4.setText("Kode Paket");
        jPanel1.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 180, -1, -1));

        jLabel5.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel5.setText("Tanggal Keberangkatan :");
        jPanel1.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(410, 180, -1, -1));

        jLabel6.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel6.setText("Cari Data :");
        jPanel1.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(410, 230, -1, -1));

        JIw.setEditable(false);
        jPanel1.add(JIw, new org.netbeans.lib.awtextra.AbsoluteConstraints(222, 51, 143, -1));

        Cs.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CsActionPerformed(evt);
            }
        });
        jPanel1.add(Cs, new org.netbeans.lib.awtextra.AbsoluteConstraints(222, 89, 143, -1));
        jPanel1.add(Jcs, new org.netbeans.lib.awtextra.AbsoluteConstraints(222, 136, 143, -1));

        Dp.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                DpActionPerformed(evt);
            }
        });
        jPanel1.add(Dp, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 180, 143, -1));
        jPanel1.add(tanggal, new org.netbeans.lib.awtextra.AbsoluteConstraints(600, 180, 143, -1));
        jPanel1.add(tgl_awal, new org.netbeans.lib.awtextra.AbsoluteConstraints(600, 230, 143, -1));

        jLabel8.setFont(new java.awt.Font("Tahoma", 0, 24)); // NOI18N
        jLabel8.setText("-");
        jPanel1.add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(800, 220, -1, -1));

        jLabel9.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel9.setText("Nama Paket");
        jPanel1.add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 230, 80, -1));
        jPanel1.add(tNm, new org.netbeans.lib.awtextra.AbsoluteConstraints(222, 226, 143, -1));

        jLabel10.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel10.setText("Tujuan");
        jPanel1.add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(406, 54, -1, -1));
        jPanel1.add(tJ, new org.netbeans.lib.awtextra.AbsoluteConstraints(600, 50, 143, -1));

        jLabel11.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel11.setText("Harga");
        jPanel1.add(jLabel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(410, 92, -1, -1));

        jLabel12.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel12.setText("Hotel");
        jPanel1.add(jLabel12, new org.netbeans.lib.awtextra.AbsoluteConstraints(414, 139, -1, -1));
        jPanel1.add(tgl_akhir, new org.netbeans.lib.awtextra.AbsoluteConstraints(870, 230, 143, -1));
        jPanel1.add(tH, new org.netbeans.lib.awtextra.AbsoluteConstraints(600, 90, 143, -1));

        tHo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tHoActionPerformed(evt);
            }
        });
        jPanel1.add(tHo, new org.netbeans.lib.awtextra.AbsoluteConstraints(600, 130, 143, -1));

        cari.setText("CARI");
        cari.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cariActionPerformed(evt);
            }
        });
        jPanel1.add(cari, new org.netbeans.lib.awtextra.AbsoluteConstraints(1070, 230, 105, -1));
        jPanel1.add(tgl, new org.netbeans.lib.awtextra.AbsoluteConstraints(720, 280, 190, 20));

        jS.setFont(new java.awt.Font("Comic Sans MS", 1, 14)); // NOI18N
        jS.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/Save.png"))); // NOI18N
        jS.setText("Simpan");
        jS.setMaximumSize(new java.awt.Dimension(105, 33));
        jS.setMinimumSize(new java.awt.Dimension(105, 33));
        jS.setPreferredSize(new java.awt.Dimension(105, 33));
        jS.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jSActionPerformed(evt);
            }
        });
        jPanel1.add(jS, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 290, -1, -1));

        BE.setFont(new java.awt.Font("Comic Sans MS", 1, 14)); // NOI18N
        BE.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/Edit.png"))); // NOI18N
        BE.setText("Edit");
        BE.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BEActionPerformed(evt);
            }
        });
        jPanel1.add(BE, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 290, 105, -1));

        Bhp.setFont(new java.awt.Font("Comic Sans MS", 1, 14)); // NOI18N
        Bhp.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/Delete.png"))); // NOI18N
        Bhp.setText("Hapus");
        Bhp.setMaximumSize(new java.awt.Dimension(105, 33));
        Bhp.setMinimumSize(new java.awt.Dimension(105, 33));
        Bhp.setPreferredSize(new java.awt.Dimension(105, 33));
        Bhp.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BhpActionPerformed(evt);
            }
        });
        jPanel1.add(Bhp, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 290, -1, -1));

        clear.setFont(new java.awt.Font("Comic Sans MS", 1, 14)); // NOI18N
        clear.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/Reset.png"))); // NOI18N
        clear.setText("Reset");
        clear.setMaximumSize(new java.awt.Dimension(105, 33));
        clear.setMinimumSize(new java.awt.Dimension(105, 33));
        clear.setPreferredSize(new java.awt.Dimension(105, 33));
        clear.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                clearActionPerformed(evt);
            }
        });
        jPanel1.add(clear, new org.netbeans.lib.awtextra.AbsoluteConstraints(510, 290, -1, -1));

        jPanel3.setBackground(new java.awt.Color(51, 102, 255));
        jPanel3.setBorder(javax.swing.BorderFactory.createTitledBorder("Tabel Wisata"));

        tabel2.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null}
            },
            new String [] {
                "ID Wisata", "ID Wisatawan", "Nama ", "Perjalanan", "Tanggal "
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, true, true
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        tabel2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tabel2MouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(tabel2);

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane1)
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 170, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 1549, Short.MAX_VALUE)
            .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, 0)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 338, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, 0)
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void tabel2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tabel2MouseClicked
        // TODO add your handling code here:
        int bar = tabel2.getSelectedRow();
      String a = tabmode.getValueAt (bar, 0) .toString();
      String b = tabmode.getValueAt (bar, 1) .toString();
           String c = tabmode.getValueAt (bar, 2) .toString();
              String d = tabmode.getValueAt (bar, 3) .toString();
                 String e = tabmode.getValueAt (bar, 4) .toString();
                    String f = tabmode.getValueAt (bar, 5) .toString();
                       String g = tabmode.getValueAt (bar, 6) .toString();
                          String h = tabmode.getValueAt (bar, 7) .toString();
                             
   
  
     try {
        java.util.Date date = new SimpleDateFormat("yyyy-MM-dd").parse((String)tabmode.getValueAt(bar, 8));
        tanggal.setDate(date);
    } catch (ParseException ex) {
        Logger.getLogger(Wisata.class.getName()).log(Level.SEVERE, null, ex);
    }

      JIw.setText(a);
      Cs.setSelectedItem(b);  
      Jcs.setText(c);
        Dp.setSelectedItem(d);
          tNm.setText(e);
            tJ.setText(f);
              tH.setText(g);
                tHo.setText(h);
                          
    }//GEN-LAST:event_tabel2MouseClicked

    private void CsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CsActionPerformed
        // TODO add your handling code here:
         customer2();
    }//GEN-LAST:event_CsActionPerformed

    private void cariActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cariActionPerformed
        // TODO add your handling code here:
        cari();
        kosong();
    }//GEN-LAST:event_cariActionPerformed

    private void DpActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_DpActionPerformed
        // TODO add your handling code here:
        paket2();
        paket3();
        paket4();
        paket5();
      
    }//GEN-LAST:event_DpActionPerformed

    private void tHoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tHoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_tHoActionPerformed

    private void jButton7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton7ActionPerformed
        // TODO add your handling code here:
        this.dispose();
    }//GEN-LAST:event_jButton7ActionPerformed

    private void jSActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jSActionPerformed
        // TODO add your handling code here:
        String sql = "insert into wisata (id_wisata,id_wisatawan,nama,kode_paket,nama_paket,tujuan,harga,hotel,tanggl) values (?,?,?,?,?,?,?,?,?)";
        try {
            PreparedStatement stat = kon.prepareStatement(sql);
            
            stat.setString(1, JIw.getText());
            stat.setString(2, Cs.getSelectedItem().toString());
            stat.setString(4, Dp.getSelectedItem().toString());
            stat.setString(3, Jcs.getText());
            stat.setString(5, tNm.getText());
            stat.setString(6, tJ.getText());
            stat.setString(7, tH.getText());
            stat.setString(8, tHo.getText());
            java.util.Date utilStartDate = tanggal.getDate();
        java.sql.Date sqlStartDate = new java.sql.Date(utilStartDate.getTime());
        stat.setDate(9, sqlStartDate);
          
           
            
            stat.executeUpdate();
            kosong();
           kode_wisata_otomatis();
            datatable();
            JOptionPane.showMessageDialog(null, "Data Berhasil Disimpan");
           
        }catch (SQLException e){
            JOptionPane.showMessageDialog(null, "Data Gagal Disimpan"+e);
        }
    }//GEN-LAST:event_jSActionPerformed

    private void BEActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BEActionPerformed
        // TODO add your handling code here:
          try{    
        String sql = "update wisata set id_wisatawan=?,nama=?, kode_paket=?,nama_paket=?,tujuan=?,harga=?,hotel=?, tanggl=? where id_wisata=?";
            PreparedStatement stat = kon.prepareStatement(sql);
            
            stat.setString(1, Cs.getSelectedItem().toString());
            stat.setString(3, Dp.getSelectedItem().toString());
            stat.setString(2, Jcs.getText());
            stat.setString(4, tNm.getText());
            stat.setString(5, tJ.getText());
            stat.setString(6, tH.getText());
            stat.setString(7, tHo.getText());
            java.util.Date utilStartDate = tanggal.getDate();
        java.sql.Date sqlStartDate = new java.sql.Date(utilStartDate.getTime());
         stat.setDate(8, sqlStartDate);
            stat.setString(9, JIw.getText());
            
            
                        
            stat.executeUpdate();
            kosong();
            datatable();
            kode_wisata_otomatis();
            JOptionPane.showMessageDialog(null, "Data Berhasil Diubah");
           
        }catch (SQLException e){
            JOptionPane.showMessageDialog(null, "Data Gagal Diubah"+e);
        }
    }//GEN-LAST:event_BEActionPerformed

    private void BhpActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BhpActionPerformed
        // TODO add your handling code here:
          int ok = JOptionPane.showConfirmDialog(null, "Yakin untuk di hapus ?","Konfirmasi Dialog", JOptionPane.YES_NO_OPTION);
       if (ok==0){
           String sql = "delete from wisata where id_wisata ='"+JIw.getText()+"'";
           try {
               PreparedStatement stat = kon.prepareStatement(sql);
               stat.executeUpdate();
               JOptionPane.showMessageDialog(null, "Data berhasil dihapus");
               datatable();
               kosong();
               kode_wisata_otomatis();
           }catch (SQLException e){
               JOptionPane.showMessageDialog(null, "Data gagal dihapus"+e);
           }
       }
    }//GEN-LAST:event_BhpActionPerformed

    private void clearActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_clearActionPerformed
        // TODO add your handling code here:
        kosong();
    }//GEN-LAST:event_clearActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Wisata.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Wisata.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Wisata.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Wisata.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Wisata().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton BE;
    private javax.swing.JButton Bhp;
    private javax.swing.JComboBox<String> Cs;
    private javax.swing.JComboBox<String> Dp;
    private javax.swing.JTextField JIw;
    private javax.swing.JTextField Jcs;
    private javax.swing.JButton cari;
    private javax.swing.JButton clear;
    private javax.swing.JButton jButton7;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JButton jS;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextField tH;
    private javax.swing.JTextField tHo;
    private javax.swing.JTextField tJ;
    private javax.swing.JTextField tNm;
    private javax.swing.JTable tabel2;
    private com.toedter.calendar.JDateChooser tanggal;
    private javax.swing.JLabel tgl;
    private com.toedter.calendar.JDateChooser tgl_akhir;
    private com.toedter.calendar.JDateChooser tgl_awal;
    // End of variables declaration//GEN-END:variables
}
