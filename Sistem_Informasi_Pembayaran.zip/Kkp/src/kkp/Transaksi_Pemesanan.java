package kkp;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author HP
 */
public class Transaksi_Pemesanan extends javax.swing.JFrame {
    
    public void kode_pemesanan_otomatis(){
      String kode="PS-000";
      int i=0;
    try{
        
        Connection kon=DriverManager.getConnection("jdbc:mysql://localhost:3306/pembayaran","root","");
        Statement stat = kon.createStatement();
        ResultSet rs = stat.executeQuery("select id_pemesanan from tb_pemesanan");
        
        while(rs.next()){
            kode = rs.getString("id_pemesanan");
        }
        kode = kode.substring(4);
        i = Integer.parseInt(kode)+1;
        kode = "00"+i;
        kode = "PS-"+kode.substring(kode.length()-3);
        id_pemesanan.setText(kode);
       
    }catch(SQLException e){
        System.out.println(e.getMessage());
    }
        
    }
    
private Connection kon = new koneksi().connect();
private DefaultTableModel tabmode;
    
    
    /**
     * Creates new form Transaksi
     */
    public Transaksi_Pemesanan() {
        initComponents();
        datatable();
        wisata();
        setLocationRelativeTo(null);
        aktif();
        kosong();
       kode_pemesanan_otomatis();
    
    }

     protected void datatable() {
        Object[] Baris ={"id_pemesanan","id_wisata","nama","nama_paket","tanggal"};
        tabmode = new DefaultTableModel(null, Baris);
        jTable1.setModel(tabmode);
        String sql = "select * from tb_pemesanan inner join wisata on tb_pemesanan.id_wisata = wisata.id_wisata";
        try {
            java.sql.Statement stat = kon.createStatement();
            ResultSet hasil = stat.executeQuery(sql);
            while(hasil.next()){
                String a = hasil.getString("id_pemesanan");
                String b = hasil.getString("id_wisata");
                String c = hasil.getString("nama");
               String d = hasil.getString("nama_paket");
                String e = hasil.getString("tanggal");
              String[] data={a,b,c,d,e};
                tabmode.addRow(data);
            }
        } catch (Exception e){}
    }
     
     protected void cari(){
        java.util.Date utilStartDate = tgl1.getDate();
        java.sql.Date sqlStartDate = new java.sql.Date(utilStartDate.getTime());
        java.util.Date utilStartDate2 = tgl2.getDate();
        java.sql.Date sqlStartDate2 = new java.sql.Date(utilStartDate2.getTime());
        hasil.setText(sqlStartDate.toString() +" s/d "+sqlStartDate2.toString());
        Object[] Baris ={"id_pemesanan","id_wisata","nama","nama_paket","tanggal"};
        tabmode = new DefaultTableModel(null, Baris);
        jTable1.setModel(tabmode);
        try {
        String sql = "select * from tb_pemesanan inner join wisata on tb_pemesanan.id_wisata = wisata.id_wisata"
                + " WHERE tanggal BETWEEN '" + sqlStartDate.toString() + "' AND '" + sqlStartDate2.toString() + "'"
                + " ORDER BY tanggal ASC";
            PreparedStatement pst = kon.prepareStatement(sql);
            ResultSet hasil = pst.executeQuery(sql);
            while(hasil.next()){
            String a = hasil.getString("id_pemesanan");
                String b = hasil.getString("id_wisata");
                String c = hasil.getString("nama");
               String d = hasil.getString("nama_paket");
                String e = hasil.getString("tanggal");
              String[] data={a,b,c,d,e};
                
                tabmode.addRow(data);
            }
        } catch (Exception e){
        JOptionPane.showMessageDialog(null,e);}
    }
    
    
     private void wisata(){
        try{
          String sql="select * from wisata";
          PreparedStatement pst = kon.prepareStatement(sql);
          ResultSet rs=pst.executeQuery(sql);          
          while(rs.next()){
          String name =rs.getString("id_wisata");
          id_wisata.addItem(name);
          }          
        }catch(Exception e){
        JOptionPane.showMessageDialog(null,e);
        }
    }
    
      private void wisata2(){
        try{
          String sql="select * from wisata where id_wisata='"+id_wisata.getSelectedItem()+"';";
          PreparedStatement pst = kon.prepareStatement(sql);
          ResultSet rs=pst.executeQuery(sql); 
          while(rs.next()){   
          String name =rs.getString("nama");
          nama.setText(name);}
            }catch(Exception e){
        JOptionPane.showMessageDialog(null,e);
        }
    }
      
      private void wisata3(){
        try{
          String sql="select * from wisata where id_wisata='"+id_wisata.getSelectedItem()+"';";
          PreparedStatement pst = kon.prepareStatement(sql);
          ResultSet rs=pst.executeQuery(sql); 
          while(rs.next()){   
          String name =rs.getString("nama_paket");
          perjalanan.setText(name);}
            }catch(Exception e){
        JOptionPane.showMessageDialog(null,e);
        }
    }
    
      private void wisata4(){
        try{
          String sql="select * from wisata where id_wisata='"+id_wisata.getSelectedItem()+"';";
          PreparedStatement pst = kon.prepareStatement(sql);
          ResultSet rs=pst.executeQuery(sql); 
          while(rs.next()){   
          String name =rs.getString("tujuan");
          tujuan.setText(name);}
            }catch(Exception e){
        JOptionPane.showMessageDialog(null,e);
        }
    }
      
      private void wisata5(){
        try{
          String sql="select * from wisata where id_wisata='"+id_wisata.getSelectedItem()+"';";
          PreparedStatement pst = kon.prepareStatement(sql);
          ResultSet rs=pst.executeQuery(sql); 
          while(rs.next()){   
          String name =rs.getString("hotel");
          hotel.setText(name);}
            }catch(Exception e){
        JOptionPane.showMessageDialog(null,e);
        }
    }
       
      private void wisata6(){
        try{
          String sql="select * from wisata where id_wisata='"+id_wisata.getSelectedItem()+"';";
          PreparedStatement pst = kon.prepareStatement(sql);
          ResultSet rs=pst.executeQuery(sql); 
          while(rs.next()){   
          String name =rs.getString("harga");
          harga.setText(name);}
            }catch(Exception e){
        JOptionPane.showMessageDialog(null,e);
        }
    }
      
      public void aktif() {
    id_pemesanan.setEnabled(true);
    id_wisata.setEnabled(true);
    nama.setEnabled(true);
  perjalanan.setEnabled(true);
  tanggal.setEnabled(true);
  
    
    }
public void kosong() {
       id_pemesanan.setText("");
       nama.setText("");
       perjalanan.setText("");
      
       tanggal.setCalendar(null);
       tgl1.setCalendar(null);
       tgl2.setCalendar(null);
    }
      
      
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel12 = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        id_pemesanan = new javax.swing.JTextField();
        id_wisata = new javax.swing.JComboBox<>();
        nama = new javax.swing.JTextField();
        perjalanan = new javax.swing.JTextField();
        tanggal = new com.toedter.calendar.JDateChooser();
        tgl1 = new com.toedter.calendar.JDateChooser();
        jLabel10 = new javax.swing.JLabel();
        tgl2 = new com.toedter.calendar.JDateChooser();
        cari2 = new javax.swing.JButton();
        jS = new javax.swing.JButton();
        BE = new javax.swing.JButton();
        Bhp = new javax.swing.JButton();
        clear = new javax.swing.JButton();
        harga = new javax.swing.JLabel();
        tujuan = new javax.swing.JLabel();
        hotel = new javax.swing.JLabel();
        jButton6 = new javax.swing.JButton();
        hasil = new javax.swing.JLabel();
        jPanel3 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(51, 102, 255));

        jLabel12.setFont(new java.awt.Font("Comic Sans MS", 1, 36)); // NOI18N
        jLabel12.setForeground(new java.awt.Color(51, 255, 0));
        jLabel12.setText("Transaksi Pemesanan");

        jPanel2.setBackground(new java.awt.Color(51, 102, 255));
        jPanel2.setBorder(javax.swing.BorderFactory.createTitledBorder("Form Pemesanan"));
        jPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel1.setText("Kode Pemesanan :");
        jPanel2.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(95, 30, -1, -1));

        jLabel2.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel2.setText("Kode Wisata       :");
        jPanel2.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(93, 88, 116, -1));

        jLabel3.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel3.setText("Nama :");
        jPanel2.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(95, 143, -1, -1));

        jLabel5.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel5.setText("Nama Paket");
        jPanel2.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(95, 204, -1, -1));

        jLabel8.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel8.setText("Tanggal :");
        jPanel2.add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(467, 30, -1, -1));

        jLabel9.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel9.setText("Cari Data :");
        jPanel2.add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(477, 88, -1, -1));

        id_pemesanan.setEditable(false);
        jPanel2.add(id_pemesanan, new org.netbeans.lib.awtextra.AbsoluteConstraints(237, 30, 179, -1));

        id_wisata.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                id_wisataActionPerformed(evt);
            }
        });
        jPanel2.add(id_wisata, new org.netbeans.lib.awtextra.AbsoluteConstraints(237, 88, 179, -1));
        jPanel2.add(nama, new org.netbeans.lib.awtextra.AbsoluteConstraints(237, 143, 179, -1));
        jPanel2.add(perjalanan, new org.netbeans.lib.awtextra.AbsoluteConstraints(237, 204, 179, -1));
        jPanel2.add(tanggal, new org.netbeans.lib.awtextra.AbsoluteConstraints(534, 30, 179, -1));
        jPanel2.add(tgl1, new org.netbeans.lib.awtextra.AbsoluteConstraints(560, 88, 132, -1));

        jLabel10.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel10.setText("-");
        jPanel2.add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(700, 90, -1, -1));
        jPanel2.add(tgl2, new org.netbeans.lib.awtextra.AbsoluteConstraints(720, 90, 132, -1));

        cari2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/Search.png"))); // NOI18N
        cari2.setText("CARI");
        cari2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cariActionPerformed(evt);
            }
        });
        jPanel2.add(cari2, new org.netbeans.lib.awtextra.AbsoluteConstraints(860, 90, 109, -1));

        jS.setFont(new java.awt.Font("Comic Sans MS", 1, 14)); // NOI18N
        jS.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/Save.png"))); // NOI18N
        jS.setText("Simpan");
        jS.setMaximumSize(new java.awt.Dimension(105, 33));
        jS.setMinimumSize(new java.awt.Dimension(105, 33));
        jS.setPreferredSize(new java.awt.Dimension(105, 33));
        jS.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jSActionPerformed(evt);
            }
        });
        jPanel2.add(jS, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 260, -1, -1));

        BE.setFont(new java.awt.Font("Comic Sans MS", 1, 14)); // NOI18N
        BE.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/Edit.png"))); // NOI18N
        BE.setText("Edit");
        BE.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BEActionPerformed(evt);
            }
        });
        jPanel2.add(BE, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 260, 105, -1));

        Bhp.setFont(new java.awt.Font("Comic Sans MS", 1, 14)); // NOI18N
        Bhp.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/Delete.png"))); // NOI18N
        Bhp.setText("Hapus");
        Bhp.setMaximumSize(new java.awt.Dimension(105, 33));
        Bhp.setMinimumSize(new java.awt.Dimension(105, 33));
        Bhp.setPreferredSize(new java.awt.Dimension(105, 33));
        Bhp.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BhpActionPerformed(evt);
            }
        });
        jPanel2.add(Bhp, new org.netbeans.lib.awtextra.AbsoluteConstraints(380, 260, -1, -1));

        clear.setFont(new java.awt.Font("Comic Sans MS", 1, 14)); // NOI18N
        clear.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/Reset.png"))); // NOI18N
        clear.setText("Reset");
        clear.setMaximumSize(new java.awt.Dimension(105, 33));
        clear.setMinimumSize(new java.awt.Dimension(105, 33));
        clear.setPreferredSize(new java.awt.Dimension(105, 33));
        clear.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                clearActionPerformed(evt);
            }
        });
        jPanel2.add(clear, new org.netbeans.lib.awtextra.AbsoluteConstraints(530, 260, -1, -1));
        jPanel2.add(harga, new org.netbeans.lib.awtextra.AbsoluteConstraints(610, 210, 160, 20));
        jPanel2.add(tujuan, new org.netbeans.lib.awtextra.AbsoluteConstraints(630, 150, 160, 20));
        jPanel2.add(hotel, new org.netbeans.lib.awtextra.AbsoluteConstraints(610, 180, 160, 20));

        jButton6.setFont(new java.awt.Font("Comic Sans MS", 1, 14)); // NOI18N
        jButton6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/Back.png"))); // NOI18N
        jButton6.setText("Back");
        jButton6.setMaximumSize(new java.awt.Dimension(105, 33));
        jButton6.setMinimumSize(new java.awt.Dimension(105, 33));
        jButton6.setPreferredSize(new java.awt.Dimension(105, 33));
        jButton6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton6ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(318, 318, 318)
                .addComponent(jLabel12)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 184, Short.MAX_VALUE)
                .addComponent(jButton6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(271, 271, 271)
                .addComponent(hasil, javax.swing.GroupLayout.PREFERRED_SIZE, 329, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel12)
                    .addComponent(jButton6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, 327, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(hasil, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        jPanel3.setBackground(new java.awt.Color(51, 102, 255));
        jPanel3.setBorder(javax.swing.BorderFactory.createTitledBorder("Tabel Pemesanan"));

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null}
            },
            new String [] {
                "Kode Pemesanan", "Kode Wisata", "Nama", "Nama Paket", "Tanggal"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, true
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jTable1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTable1MouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(jTable1);

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addComponent(jScrollPane1)
                .addContainerGap())
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 132, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 412, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, 0))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jTable1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTable1MouseClicked
        // TODO add your handling code here:
        int bar = jTable1.getSelectedRow();
      String a = tabmode.getValueAt (bar, 0) .toString();
      String b = tabmode.getValueAt (bar, 1) .toString();
        String c = tabmode.getValueAt (bar, 2) .toString();
     String d = tabmode.getValueAt (bar, 3) .toString();
     
  
     try {
        java.util.Date date = new SimpleDateFormat("yyyy-MM-dd").parse((String)tabmode.getValueAt(bar, 4));
        tanggal.setDate(date);
    } catch (ParseException ex) {
        Logger.getLogger(Wisata.class.getName()).log(Level.SEVERE, null, ex);
    }
   
     
      id_pemesanan.setText(a);
      id_wisata.setSelectedItem(b);
        nama.setText(c);
        perjalanan.setText(d);
    }//GEN-LAST:event_jTable1MouseClicked

    private void jButton6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton6ActionPerformed
        // TODO add your handling code here:
        this.dispose();
    }//GEN-LAST:event_jButton6ActionPerformed

    private void clearActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_clearActionPerformed
        // TODO add your handling code here:
        kosong();
        kode_pemesanan_otomatis();
    }//GEN-LAST:event_clearActionPerformed

    private void BhpActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BhpActionPerformed
        // TODO add your handling code here:
        int ok = JOptionPane.showConfirmDialog(null, "Yakin untuk di hapus ?","Konfirmasi Dialog", JOptionPane.YES_NO_OPTION);
        if (ok==0){
            String sql = "delete from tb_pemesanan where id_pemesanan ='"+id_pemesanan.getText()+"'";
            try {
                PreparedStatement stat = kon.prepareStatement(sql);
                stat.executeUpdate();
                JOptionPane.showMessageDialog(null, "Data berhasil dihapus");
                datatable();
                kosong();
                kode_pemesanan_otomatis();
            }catch (SQLException e){
                JOptionPane.showMessageDialog(null, "Data gagal dihapus"+e);
            }
        }
    }//GEN-LAST:event_BhpActionPerformed

    private void BEActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BEActionPerformed
        // TODO add your handling code here:
        try{
            String sql = "update tb_pemesanan set id_wisata=?,nama=?,nama_paket=?,tujuan=?,hotel=?,harga=?, tanggal=? where id_pemesanan=?";
            PreparedStatement stat = kon.prepareStatement(sql);
            stat.setString(1, id_wisata.getSelectedItem().toString());
         stat.setString(2, nama.getText());
         stat.setString(3, perjalanan.getText());
         stat.setString(4, tujuan.getText());
            stat.setString(5, hotel.getText());
            stat.setString(6, harga.getText());
            
            java.util.Date utilStartDate = tanggal.getDate();
            java.sql.Date sqlStartDate = new java.sql.Date(utilStartDate.getTime());
            stat.setDate(7, sqlStartDate);
            stat.setString(8, id_pemesanan.getText());

            stat.executeUpdate();
            kosong();
            datatable();
            kode_pemesanan_otomatis();
            JOptionPane.showMessageDialog(null, "Data Berhasil Diubah");

        }catch (SQLException e){
            JOptionPane.showMessageDialog(null, "Data Gagal Diubah"+e);
        }
    }//GEN-LAST:event_BEActionPerformed

    private void jSActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jSActionPerformed
        // TODO add your handling code here:
        String sql = "insert into tb_pemesanan (id_pemesanan,id_wisata,nama,nama_paket,tujuan,hotel,harga,tanggal) values (?,?,?,?,?,?,?,?)";
        try {
            PreparedStatement stat = kon.prepareStatement(sql);

            stat.setString(1, id_pemesanan.getText());
            stat.setString(2, id_wisata.getSelectedItem().toString());
            stat.setString(3, nama.getText());
            stat.setString(4, perjalanan.getText());
            stat.setString(5, tujuan.getText());
            stat.setString(6, hotel.getText());
            stat.setString(7, harga.getText());
            java.util.Date utilStartDate = tanggal.getDate();
            java.sql.Date sqlStartDate = new java.sql.Date(utilStartDate.getTime());
            stat.setDate(8, sqlStartDate);

            stat.executeUpdate();
            kosong();
            datatable();
            kode_pemesanan_otomatis();
            JOptionPane.showMessageDialog(null, "Data Berhasil Disimpan");

        }catch (SQLException e){
            JOptionPane.showMessageDialog(null, "Data Gagal Disimpan"+e);
        }
    }//GEN-LAST:event_jSActionPerformed

    private void id_wisataActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_id_wisataActionPerformed
        // TODO add your handling code here:
        wisata2();
        wisata3();
        wisata4();
        wisata5();
        wisata6();
    }//GEN-LAST:event_id_wisataActionPerformed

    private void cariActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cariActionPerformed
        // TODO add your handling code here:
        cari();
    }//GEN-LAST:event_cariActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Transaksi_Pemesanan.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Transaksi_Pemesanan.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Transaksi_Pemesanan.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Transaksi_Pemesanan.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Transaksi_Pemesanan().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton BE;
    private javax.swing.JButton Bhp;
    private javax.swing.JButton cari2;
    private javax.swing.JButton clear;
    private javax.swing.JLabel harga;
    private javax.swing.JLabel hasil;
    private javax.swing.JLabel hotel;
    private javax.swing.JTextField id_pemesanan;
    private javax.swing.JComboBox<String> id_wisata;
    private javax.swing.JButton jButton6;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JButton jS;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable1;
    private javax.swing.JTextField nama;
    private javax.swing.JTextField perjalanan;
    private com.toedter.calendar.JDateChooser tanggal;
    private com.toedter.calendar.JDateChooser tgl1;
    private com.toedter.calendar.JDateChooser tgl2;
    private javax.swing.JLabel tujuan;
    // End of variables declaration//GEN-END:variables
}
