/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package kkp;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author Windows10
 */
public class pembayaran extends javax.swing.JFrame {
    
    public void kode_pembayaran_otomatis(){
      String kode="BR-000";
      int i=0;
    try{
        
        Connection kon=DriverManager.getConnection("jdbc:mysql://localhost:3306/pembayaran","root","");
        Statement stat = kon.createStatement();
        ResultSet rs = stat.executeQuery("select id_pembayaran from bayar");
        
        while(rs.next()){
            kode = rs.getString("id_pembayaran");
        }
        kode = kode.substring(4);
        i = Integer.parseInt(kode)+1;
        kode = "00"+i;
        kode = "BR-"+kode.substring(kode.length()-3);
        id_pembayaran.setText(kode);
       
    }catch(SQLException e){
        System.out.println(e.getMessage());
    }
        
    }
    
private Connection kon = new koneksi().connect();
private DefaultTableModel tabmode;
    /**
     * Creates new form pembayaran
     */
    public pembayaran() {
        initComponents();
        pesan();
        datatable();
        setLocationRelativeTo(null);
        aktif();
        kosong();
        kode_pembayaran_otomatis();
    }

    protected void datatable() {
        Object[] Baris ={"id_pembayaran","id_pemesanan","nama","nama_paket","tujuan","hotel","harga","jenis_pembayaran","tnggl"};
        tabmode = new DefaultTableModel(null, Baris);
        jTable2.setModel(tabmode);
        String sql =  "select * from bayar inner join tb_pemesanan on bayar.id_pemesanan = tb_pemesanan.id_pemesanan";
        try {
            java.sql.Statement stat = kon.createStatement();
            ResultSet hasil = stat.executeQuery(sql);
            while(hasil.next()){
                String a = hasil.getString("id_pembayaran");
                String b = hasil.getString("id_pemesanan");
                String c = hasil.getString("nama");
                String d = hasil.getString("nama_paket");
                     String e = hasil.getString("tujuan");
                     String f = hasil.getString("hotel");
                        String g = hasil.getString("harga");
                           String h = hasil.getString("jenis_pembayaran");
                String i = hasil.getString("tnggl");
              String[] data={a,b,c,d,e,f,g,h,i};
                tabmode.addRow(data);
            }
        } catch (Exception e){}
    
    }
        protected void cari(){
        java.util.Date utilStartDate = tgl_awal.getDate();
        java.sql.Date sqlStartDate = new java.sql.Date(utilStartDate.getTime());
        java.util.Date utilStartDate2 = tgl_akhir.getDate();
        java.sql.Date sqlStartDate2 = new java.sql.Date(utilStartDate2.getTime());
        tgl.setText(sqlStartDate.toString() +" s/d "+sqlStartDate2.toString());
        Object[] Baris ={"id_pembayaran","id_pemesanan","nama","nama_paket","tujuan","hotel","harga","jenis_pembayaran","tnggl"};
        tabmode = new DefaultTableModel(null, Baris);
        jTable2.setModel(tabmode);
        try {
        String sql =  "select * from bayar inner join tb_pemesanan on bayar.id_pemesanan=tb_pemesanan.id_pemesanan"
                + " WHERE tnggl BETWEEN '" + sqlStartDate.toString() + "' AND '" + sqlStartDate2.toString() + "'"
                + " ORDER BY tnggl ASC";
            PreparedStatement pst = kon.prepareStatement(sql);
            ResultSet hasil = pst.executeQuery(sql);
            while(hasil.next()){
           String a = hasil.getString("id_pembayaran");
                String b = hasil.getString("id_pemesanan");
                String c = hasil.getString("nama");
                String d = hasil.getString("nama_paket");
                     String e = hasil.getString("tujuan");
                     String f = hasil.getString("hotel");
                        String g = hasil.getString("harga");
                           String h = hasil.getString("jenis_pembayaran");
                String i = hasil.getString("tnggl");
              String[] data={a,b,c,d,e,f,g,h,i};
              tabmode.addRow(data);
            }
        } catch (Exception e){
        JOptionPane.showMessageDialog(null,e);}
    }
        
        private void pesan(){
        try{
          String sql="select * from tb_pemesanan";
          PreparedStatement pst = kon.prepareStatement(sql);
          ResultSet rs=pst.executeQuery(sql);          
          while(rs.next()){
          String name =rs.getString("id_pemesanan");
          id_pemesanan.addItem(name);
          }          
        }catch(Exception e){
        JOptionPane.showMessageDialog(null,e);
        }
    }
        
        private void pesan2(){
        try{
          String sql="select * from tb_pemesanan where id_pemesanan ='"+id_pemesanan.getSelectedItem()+"';";
          PreparedStatement pst = kon.prepareStatement(sql);
          ResultSet rs=pst.executeQuery(sql); 
          while(rs.next()){   
          String name =rs.getString("nama");
          nama.setText(name);     
          }
            }catch(Exception e){
        JOptionPane.showMessageDialog(null,e);
        }
    }
        
        private void pesan3(){
        try{
          String sql="select * from tb_pemesanan where id_pemesanan ='"+id_pemesanan.getSelectedItem()+"';";
          PreparedStatement pst = kon.prepareStatement(sql);
          ResultSet rs=pst.executeQuery(sql); 
          while(rs.next()){   
          String name =rs.getString("nama_paket");
          paket.setText(name);     
          }
            }catch(Exception e){
        JOptionPane.showMessageDialog(null,e);
        }
    }
        
        private void pesan4(){
        try{
          String sql="select * from tb_pemesanan where id_pemesanan ='"+id_pemesanan.getSelectedItem()+"';";
          PreparedStatement pst = kon.prepareStatement(sql);
          ResultSet rs=pst.executeQuery(sql); 
          while(rs.next()){   
          String name =rs.getString("tujuan");
          tujuan.setText(name);     
          }
            }catch(Exception e){
        JOptionPane.showMessageDialog(null,e);
        }
    }
        
        private void pesan5(){
        try{
          String sql="select * from tb_pemesanan where id_pemesanan ='"+id_pemesanan.getSelectedItem()+"';";
          PreparedStatement pst = kon.prepareStatement(sql);
          ResultSet rs=pst.executeQuery(sql); 
          while(rs.next()){   
          String name =rs.getString("hotel");
          hotel.setText(name);     
          }
            }catch(Exception e){
        JOptionPane.showMessageDialog(null,e);
        }
    }
        
        private void pesan6(){
        try{
          String sql="select * from tb_pemesanan where id_pemesanan ='"+id_pemesanan.getSelectedItem()+"';";
          PreparedStatement pst = kon.prepareStatement(sql);
          ResultSet rs=pst.executeQuery(sql); 
          while(rs.next()){   
          String name =rs.getString("harga");
          harga.setText(name);     
          }
            }catch(Exception e){
        JOptionPane.showMessageDialog(null,e);
        }
    }
        
        public void aktif() {
    id_pembayaran.setEnabled(true);
    nama.setEnabled(true);
        paket.setEnabled(true);
         tujuan.setEnabled(true);
          hotel.setEnabled(true);
           harga.setEnabled(true);
           jenis_pembayaran.setEnabled(true);
  tanggal.setEnabled(true);
  
    
    }
        
        public void kosong() {
       id_pembayaran.setText("");
       nama.setText("");
         paket.setText("");
           tujuan.setText("");
             hotel.setText("");
               harga.setText("");
               jenis_pembayaran.setText("Tunai");
       tanggal.setCalendar(null);
       
       
       
    }
        
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jPanel1 = new javax.swing.JPanel();
        jButton6 = new javax.swing.JButton();
        jLabel13 = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        id_pembayaran = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        id_pemesanan = new javax.swing.JComboBox<>();
        jLabel4 = new javax.swing.JLabel();
        nama = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        paket = new javax.swing.JTextField();
        jLabel11 = new javax.swing.JLabel();
        hotel = new javax.swing.JTextField();
        jLabel7 = new javax.swing.JLabel();
        harga = new javax.swing.JTextField();
        jLabel8 = new javax.swing.JLabel();
        jenis_pembayaran = new javax.swing.JTextField();
        jLabel9 = new javax.swing.JLabel();
        tanggal = new com.toedter.calendar.JDateChooser();
        jLabel12 = new javax.swing.JLabel();
        tgl_awal = new com.toedter.calendar.JDateChooser();
        tgl_akhir = new com.toedter.calendar.JDateChooser();
        jLabel6 = new javax.swing.JLabel();
        cari = new javax.swing.JButton();
        jLabel10 = new javax.swing.JLabel();
        tujuan = new javax.swing.JTextField();
        simpan = new javax.swing.JButton();
        edit = new javax.swing.JButton();
        hapus = new javax.swing.JButton();
        reset = new javax.swing.JButton();
        tgl = new javax.swing.JLabel();
        jPanel3 = new javax.swing.JPanel();
        jScrollPane2 = new javax.swing.JScrollPane();
        jTable2 = new javax.swing.JTable();

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane1.setViewportView(jTable1);

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setBackground(new java.awt.Color(51, 102, 255));

        jPanel1.setBackground(new java.awt.Color(51, 102, 255));

        jButton6.setFont(new java.awt.Font("Comic Sans MS", 1, 14)); // NOI18N
        jButton6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/Back.png"))); // NOI18N
        jButton6.setText("Back");
        jButton6.setMaximumSize(new java.awt.Dimension(105, 33));
        jButton6.setMinimumSize(new java.awt.Dimension(105, 33));
        jButton6.setPreferredSize(new java.awt.Dimension(105, 33));
        jButton6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton6ActionPerformed(evt);
            }
        });

        jLabel13.setBackground(new java.awt.Color(0, 0, 0));
        jLabel13.setFont(new java.awt.Font("Comic Sans MS", 0, 28)); // NOI18N
        jLabel13.setForeground(new java.awt.Color(51, 255, 0));
        jLabel13.setText("Transaksi Pembayaran");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel13)
                .addGap(441, 441, 441)
                .addComponent(jButton6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(38, 38, 38))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap(24, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jButton6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel13))
                .addContainerGap())
        );

        jPanel2.setBackground(new java.awt.Color(51, 102, 255));
        jPanel2.setBorder(javax.swing.BorderFactory.createTitledBorder("Form Pembayaran"));

        jLabel2.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel2.setText("Kode Pembayaran :");

        jLabel3.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel3.setText("Kode Pemesanan :");

        id_pemesanan.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                id_pemesananActionPerformed(evt);
            }
        });

        jLabel4.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel4.setText("Nama :");
        jLabel4.setToolTipText("");

        jLabel5.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel5.setText("Nama Paket :");

        jLabel11.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel11.setText("Hotel :");

        jLabel7.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel7.setText(" Harga :");

        jLabel8.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel8.setText("Jenis Pembayaran :");

        jenis_pembayaran.setEditable(false);
        jenis_pembayaran.setText("Tunai");
        jenis_pembayaran.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jenis_pembayaranActionPerformed(evt);
            }
        });

        jLabel9.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel9.setText("Tanggal Pembayaran :");

        jLabel12.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel12.setText("Cari Data :");

        jLabel6.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel6.setText("-");

        cari.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/Search.png"))); // NOI18N
        cari.setText("CARI");
        cari.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cariActionPerformed(evt);
            }
        });

        jLabel10.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel10.setText("Tujuan");

        simpan.setFont(new java.awt.Font("Comic Sans MS", 1, 14)); // NOI18N
        simpan.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/Save.png"))); // NOI18N
        simpan.setText("Simpan");
        simpan.setMaximumSize(new java.awt.Dimension(105, 33));
        simpan.setMinimumSize(new java.awt.Dimension(105, 33));
        simpan.setPreferredSize(new java.awt.Dimension(105, 33));
        simpan.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                simpanActionPerformed(evt);
            }
        });

        edit.setFont(new java.awt.Font("Comic Sans MS", 1, 14)); // NOI18N
        edit.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/Edit.png"))); // NOI18N
        edit.setText("Edit");
        edit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                editActionPerformed(evt);
            }
        });

        hapus.setFont(new java.awt.Font("Comic Sans MS", 1, 14)); // NOI18N
        hapus.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/Delete.png"))); // NOI18N
        hapus.setText("Hapus");
        hapus.setMaximumSize(new java.awt.Dimension(105, 33));
        hapus.setMinimumSize(new java.awt.Dimension(105, 33));
        hapus.setPreferredSize(new java.awt.Dimension(105, 33));
        hapus.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                hapusActionPerformed(evt);
            }
        });

        reset.setFont(new java.awt.Font("Comic Sans MS", 1, 14)); // NOI18N
        reset.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/Reset.png"))); // NOI18N
        reset.setText("Reset");
        reset.setMaximumSize(new java.awt.Dimension(105, 33));
        reset.setMinimumSize(new java.awt.Dimension(105, 33));
        reset.setPreferredSize(new java.awt.Dimension(105, 33));
        reset.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                resetActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel2)
                            .addComponent(jLabel3)
                            .addComponent(jLabel4)
                            .addComponent(jLabel5)
                            .addComponent(jLabel10))
                        .addGap(59, 59, 59)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(tujuan, javax.swing.GroupLayout.PREFERRED_SIZE, 173, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(id_pembayaran, javax.swing.GroupLayout.PREFERRED_SIZE, 173, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(id_pemesanan, javax.swing.GroupLayout.PREFERRED_SIZE, 173, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(nama, javax.swing.GroupLayout.PREFERRED_SIZE, 173, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(paket, javax.swing.GroupLayout.PREFERRED_SIZE, 173, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(simpan, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(46, 46, 46)
                        .addComponent(edit, javax.swing.GroupLayout.PREFERRED_SIZE, 105, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(43, 43, 43)
                        .addComponent(hapus, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(35, 35, 35)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(reset, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(114, 114, 114)
                        .addComponent(tgl, javax.swing.GroupLayout.PREFERRED_SIZE, 233, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(jLabel8)
                        .addGap(37, 37, 37)
                        .addComponent(jenis_pembayaran, javax.swing.GroupLayout.PREFERRED_SIZE, 173, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel11)
                            .addComponent(jLabel7))
                        .addGap(107, 107, 107)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(harga, javax.swing.GroupLayout.PREFERRED_SIZE, 173, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(hotel, javax.swing.GroupLayout.PREFERRED_SIZE, 173, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel9)
                            .addComponent(jLabel12))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(tanggal, javax.swing.GroupLayout.PREFERRED_SIZE, 173, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addComponent(tgl_awal, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(63, 63, 63)
                                .addComponent(jLabel6)
                                .addGap(51, 51, 51)
                                .addComponent(tgl_akhir, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(78, 78, 78)
                                .addComponent(cari, javax.swing.GroupLayout.PREFERRED_SIZE, 97, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                .addContainerGap(906, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(id_pembayaran, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel11)
                    .addComponent(hotel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(id_pemesanan, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel7)
                    .addComponent(harga, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(nama, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel8)
                    .addComponent(jenis_pembayaran, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jLabel5)
                        .addComponent(paket, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jLabel9))
                    .addComponent(tanggal, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(tgl_akhir, javax.swing.GroupLayout.DEFAULT_SIZE, 32, Short.MAX_VALUE)
                    .addComponent(tgl_awal, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jLabel12)
                        .addComponent(tujuan, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(cari)
                    .addComponent(jLabel10)
                    .addComponent(jLabel6))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 44, Short.MAX_VALUE)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(simpan, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(edit)
                        .addComponent(hapus, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(reset, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(tgl, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(19, Short.MAX_VALUE))
        );

        jPanel3.setBackground(new java.awt.Color(51, 102, 255));
        jPanel3.setBorder(javax.swing.BorderFactory.createTitledBorder("Tabel Pembayaran"));

        jTable2.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jTable2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTable2MouseClicked(evt);
            }
        });
        jScrollPane2.setViewportView(jTable2);

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane2)
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 187, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 16, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, 0)
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, 0)
                .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void id_pemesananActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_id_pemesananActionPerformed
        // TODO add your handling code here:
        pesan2();
        pesan3();
        pesan4();
        pesan5();
        pesan6();
        
    }//GEN-LAST:event_id_pemesananActionPerformed

    private void cariActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cariActionPerformed
        // TODO add your handling code here:
        cari();
        kosong();
    }//GEN-LAST:event_cariActionPerformed

    private void simpanActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_simpanActionPerformed
        // TODO add your handling code here:
        String sql = "insert into bayar (id_pembayaran,id_pemesanan,nama,nama_paket,tujuan,hotel,harga,jenis_pembayaran,tnggl) values (?,?,?,?,?,?,?,?,?)";
        try {
            PreparedStatement stat = kon.prepareStatement(sql);

            stat.setString(1, id_pembayaran.getText());
            stat.setString(2, id_pemesanan.getSelectedItem().toString());
            stat.setString(3, nama.getText());
            stat.setString(4, paket.getText());
            stat.setString(5, tujuan.getText());
            stat.setString(6, hotel.getText());
            stat.setString(7, harga.getText());
            stat.setString(8, jenis_pembayaran.getText());
          
            java.util.Date utilStartDate = tanggal.getDate();
            java.sql.Date sqlStartDate = new java.sql.Date(utilStartDate.getTime());
            stat.setDate(9, sqlStartDate);

            stat.executeUpdate();
            kosong();
            datatable();
            kode_pembayaran_otomatis();
            JOptionPane.showMessageDialog(null, "Data Berhasil Disimpan");

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Data Gagal Disimpan" + e);
        }
    }//GEN-LAST:event_simpanActionPerformed

    private void editActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_editActionPerformed
        // TODO add your handling code here:
        try{
            String sql = "update bayar set id_pemesanan=?,nama=?,nama_paket=?,tujuan=?,hotel=?,harga=?, jenis_pembayaran=?, tnggl=? where id_pembayaran=?";
            PreparedStatement stat = kon.prepareStatement(sql);
            stat.setString(1, id_pemesanan.getSelectedItem().toString());
            stat.setString(2, nama.getText());
            stat.setString(3, paket.getText());
            stat.setString(4, tujuan.getText());
            stat.setString(5, hotel.getText());
            stat.setString(6, harga.getText());
            stat.setString(7, jenis_pembayaran.getText());
            java.util.Date utilStartDate = tanggal.getDate();
            java.sql.Date sqlStartDate = new java.sql.Date(utilStartDate.getTime());
            stat.setDate(8, sqlStartDate);
            stat.setString(9, id_pembayaran.getText());

            stat.executeUpdate();
            kosong();
            datatable();
            kode_pembayaran_otomatis();
            JOptionPane.showMessageDialog(null, "Data Berhasil Diubah");

        }catch (SQLException e){
            JOptionPane.showMessageDialog(null, "Data Gagal Diubah"+e);
        }
    }//GEN-LAST:event_editActionPerformed

    private void hapusActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_hapusActionPerformed
        // TODO add your handling code here:
        int ok = JOptionPane.showConfirmDialog(null, "Yakin untuk di hapus ?","Konfirmasi Dialog", JOptionPane.YES_NO_OPTION);
        if (ok==0){
            String sql = "delete from bayar where id_pembayaran ='"+id_pembayaran.getText()+"'";
            try {
                PreparedStatement stat = kon.prepareStatement(sql);
                stat.executeUpdate();
                JOptionPane.showMessageDialog(null, "Data berhasil dihapus");
                datatable();
                kosong();
                kode_pembayaran_otomatis();
            }catch (SQLException e){
                JOptionPane.showMessageDialog(null, "Data gagal dihapus"+e);
            }
        }
    }//GEN-LAST:event_hapusActionPerformed

    private void resetActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_resetActionPerformed
        // TODO add your handling code here:
        kosong();
        kode_pembayaran_otomatis();
    }//GEN-LAST:event_resetActionPerformed

    private void jTable2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTable2MouseClicked
        // TODO add your handling code here:
        int bar = jTable2.getSelectedRow();
      String a = tabmode.getValueAt (bar, 0) .toString();
      String b = tabmode.getValueAt (bar, 1) .toString();
           String c = tabmode.getValueAt (bar, 2) .toString();
              String d = tabmode.getValueAt (bar, 3) .toString();
                 String e = tabmode.getValueAt (bar, 4) .toString();
                    String f = tabmode.getValueAt (bar, 5) .toString();
                       String g = tabmode.getValueAt (bar, 6) .toString();
                          String h = tabmode.getValueAt (bar, 7) .toString();
                             
   
  
     try {
        java.util.Date date = new SimpleDateFormat("yyyy-MM-dd").parse((String)tabmode.getValueAt(bar, 8));
        tanggal.setDate(date);
    } catch (ParseException ex) {
        Logger.getLogger(Wisata.class.getName()).log(Level.SEVERE, null, ex);
    }

      id_pembayaran.setText(a);
      id_pemesanan.setSelectedItem(b);  
      nama.setText(c);
        paket.setText(d);
          tujuan.setText(e);
            hotel.setText(f);
              harga.setText(g);
                jenis_pembayaran.setText(h);
    }//GEN-LAST:event_jTable2MouseClicked

    private void jButton6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton6ActionPerformed
        // TODO add your handling code here:
        this.dispose();
    }//GEN-LAST:event_jButton6ActionPerformed

    private void jenis_pembayaranActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jenis_pembayaranActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jenis_pembayaranActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(pembayaran.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(pembayaran.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(pembayaran.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(pembayaran.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new pembayaran().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton cari;
    private javax.swing.JButton edit;
    private javax.swing.JButton hapus;
    private javax.swing.JTextField harga;
    private javax.swing.JTextField hotel;
    private javax.swing.JTextField id_pembayaran;
    private javax.swing.JComboBox<String> id_pemesanan;
    private javax.swing.JButton jButton6;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTable jTable1;
    private javax.swing.JTable jTable2;
    private javax.swing.JTextField jenis_pembayaran;
    private javax.swing.JTextField nama;
    private javax.swing.JTextField paket;
    private javax.swing.JButton reset;
    private javax.swing.JButton simpan;
    private com.toedter.calendar.JDateChooser tanggal;
    private javax.swing.JLabel tgl;
    private com.toedter.calendar.JDateChooser tgl_akhir;
    private com.toedter.calendar.JDateChooser tgl_awal;
    private javax.swing.JTextField tujuan;
    // End of variables declaration//GEN-END:variables


        
    
}
